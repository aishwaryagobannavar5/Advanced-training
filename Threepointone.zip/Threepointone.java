package advJava;

public abstract class Threepointone
{
public abstract void Play();
}