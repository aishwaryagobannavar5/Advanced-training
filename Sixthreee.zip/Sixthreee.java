package advJava;
import java.util.LinkedList;
import java.util.Vector;

public class Sixthreee {
	private static final Sixthreee[] v = null;

	public static void main(String[] args) {
		LinkedList<Sixthreee> v = addInput();
		display(v);
	}

	private static LinkedList<Sixthreee> addInput() {
		Sixthree e1 = new Sixthree(101, "Vikrant", "Pune");
		Sixthree e2 = new Sixthree(102, "Nilesh", "Nashik");
		Sixthree e3 = new Sixthree(103, "Shishir", "Mumbai");
		LinkedList<Sixthree> v = new LinkedList<Sixthree>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(LinkedList<Employee> v) {
		for (Sixthree e : v) {
			System.out.println(e.getEmpid() + "\t" + e.getEname() + "\t" + e.getAddress());
		}
	}

}