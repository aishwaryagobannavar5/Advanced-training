package advJava;

import java.util.Scanner;

public class Onepointthreee
{
	public static Onepointthree[] createBooks(int n) {
	    // Scanner scan = new Scanner(System.in);
	    // int n= scan.nextInt();
	    
	    Onepointthree obj[]= new Onepointthree[n];

	    for(int i=0; i<n; i++){
	      obj[i]= new Onepointthree();
	      obj[i].setBook_title("Title "+ i);
	      obj[i].setBook_price(i*100);
	    }
	    
	    return obj;
	  }

	  public static void showBooks(Onepointthree obj[], int n) {
	    System.out.println("Book Title      Price");
	    for(int i=0; i<n; i++){
	      System.out.print(obj[i].getBook_title());
	      System.out.print("      ");
	      System.out.println(obj[i].getBook_price());
	    }
	  }
    public static void main (String[] args) {
    	Scanner sc = new Scanner(System.in);
	    int n= sc.nextInt();
        
        System.out.println("Enter the Book name:");
        String bookname=sc.nextLine();
        
        System.out.println("Enter the price:");
        int price=sc.nextInt();
        sc.nextLine();
        
        
        Onepointthree obj=new Onepointthree();
        
        obj.setBook_title(bookname);
        obj.setBook_price(price);
        System.out.println("Book Details");
        System.out.println("Book Name :"+obj.getBook_title());
        System.out.println("Book Price :"+obj.getBook_price());
        showBooks(createBooks(n), n);
        
       
    }
}

